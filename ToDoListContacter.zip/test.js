const moment = require("moment");

let a = moment().diff(moment("2020-06-17"), "day");

console.log(a);
